Please run the index.html, for the landingpage.
Each image in the landing page takes to the another page with the information to process.
Once you click the BUY button, it will take to the billing process.